// Copyright 2023, Solieyagai15409. All Rights Reserved.

#pragma once

#include "Modules/ModuleManager.h"

class FColorPickerModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;


};
